package com.example.jonmo.mortgagecalcjmo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText; // for bill amount input
import android.widget.TextView; // for displaying text
import java.text.NumberFormat; // for currency formatting


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    // currency and percent formatter objects
    private static final NumberFormat currencyFormat =
            NumberFormat.getCurrencyInstance();
    private static final NumberFormat percentFormat =
            NumberFormat.getPercentInstance();

    private int houseValue; // house amount entered by the user
    private double apr; // initial APR percentage (close to current market rate)
    private double downPayment;
    private int mortgageLength;

    private TextView APRpercentTextView; // shows formatted APR Amount

    private TextView monthlyPaymentTextView;
    private TextView totalPaymentsTextView;
    Button calculateButton, clearButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("MortgageCalcJMO", "I am here");
        // get references to programmatically manipulated TextViews assign reference variable to the ID in XML file
        //  houseValue = (TextView) findViewById(R.id.houseValueEditText);
        monthlyPaymentTextView = (TextView) findViewById(R.id.monthlyPaymentTextView);
        totalPaymentsTextView = (TextView) findViewById(R.id.totalPaymentTextView);

        monthlyPaymentTextView.setText(currencyFormat.format(0));// initially set to zero since user hasn't entered anything yet
        totalPaymentsTextView.setText(currencyFormat.format(0)); //currency format makes the user see 0.00

        calculateButton = findViewById(R.id.calculateButton);
        calculateButton.setOnClickListener(this);

        clearButton = findViewById(R.id.clearButton);
        clearButton.setOnClickListener(this);

    }

    private void calculate() {
// calculate the tip and total
        //double test = downPayment;

        double monthlyPayment = 0;
        double totalPayment = 0;
        Log.d("MortgageCalcJMO","APR "+apr );
      //  Monthly Interest Rate = Annual Interest Rate / (12 * 100)
      //  Months = Number of months over which loan is amortized
      //          = (Length of Mortgage in Years * 12)
      //  Loan Amount = (House Price – Down Payment Amount)
       long loanAmount = (long) (houseValue-downPayment);
        Log.d("MortgageCalcJMO","houseValue-DownPayment "+loanAmount );
       double monthlyInterestRate =  apr/(12*100);
        Log.d("MortgageCalcJMO","Monthly Interest "+monthlyInterestRate );
       double months = mortgageLength*12;
        Log.d("MortgageCalcJMO","Months "+ months );
        if (monthlyInterestRate == 0)
            monthlyPayment =  ((loanAmount) / (1.0 - Math.pow(((1.0 + monthlyInterestRate) - months), -months)));
        else{

         //monthlyPayment = numerator/denominator;
            monthlyPayment = (loanAmount*monthlyInterestRate)/(1 - Math.pow((1+monthlyInterestRate), -months));
        }


        Log.d("MortgageCalcJMO","monthly Payment "+monthlyPayment );
       totalPayment = monthlyPayment*months;
                            // Loan Amount * Monthly Interest Rate
       // Monthly Payment = --------------------------------------
                        //        1 - (1 + Monthly Interest Rate)-Months
      //  Total payment = Monthly payment * Months


        monthlyPaymentTextView.setText(currencyFormat.format(monthlyPayment));
        totalPaymentsTextView.setText(currencyFormat.format(totalPayment));

    }


    @Override
    public void onClick(View v) {
        EditText houseValueEditText = (EditText)findViewById(R.id.houseValueEditText);
        EditText downPaymentEditText = (EditText)findViewById(R.id.downPaymentEditText);
        EditText aprEditText = (EditText)findViewById(R.id.interestRateEditText);
        EditText mortgageLengthText = (EditText)findViewById(R.id.mortgageLengthText);


        switch (v.getId()) {

            case R.id.calculateButton:
                Log.d("MortgageCalcJMO","calc button initiated");
               // EditText houseValueEditText = (EditText)findViewById(R.id.houseValueEditText);
              try {
                  String sTextFromET = houseValueEditText.getText().toString();
                  houseValue = new Integer(sTextFromET).intValue();
                  // house amount entered by the user
                  //  EditText downPaymentEditText = (EditText)findViewById(R.id.downPaymentEditText);
                  String sTextFromET2 = downPaymentEditText.getText().toString();
                  downPayment = new Integer(sTextFromET2).intValue();

                  // EditText aprEditText = (EditText)findViewById(R.id.interestRateEditText);
                  String sTextFromET3 = aprEditText.getText().toString();
                  apr = new Double(sTextFromET3).doubleValue();

                  //EditText mortgageLengthText = (EditText)findViewById(R.id.mortgageLengthText);
                  String sTextFromET4 = mortgageLengthText.getText().toString();
                  mortgageLength = new Integer(sTextFromET4).intValue();
                  calculate();
              }
              catch(Exception exception){

            }
                break;

            case R.id.clearButton:
                Log.d("MortgageCalcJMO","Clear button");
                houseValueEditText.setText("");
                downPaymentEditText.setText("");
                aprEditText.setText("");
                mortgageLengthText.setText("");
                monthlyPaymentTextView.setText("");
                totalPaymentsTextView.setText("");

                break;

            default:
                break;
        }

    }
}
